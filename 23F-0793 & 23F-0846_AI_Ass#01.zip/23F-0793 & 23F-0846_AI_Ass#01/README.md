<<<<<<< HEAD
# AI 2002 Assignment 1
=======
# AI_Assignment01
Implemented Different Searching Algorithms in Python
>>>>>>> 58500eee1f2d7a14d646de9fd4b4f7e2c0f6f9cb

## Installation

pip install matplotlib numpy

## Run

python bfs.py
python dfs.py
python ucs.py
python dls.py
python iddfs.py
<<<<<<< HEAD
python bidirectional.py
=======
python bidirectional.py
>>>>>>> 58500eee1f2d7a14d646de9fd4b4f7e2c0f6f9cb
